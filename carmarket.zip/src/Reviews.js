import React from "react";
import "./Reviews.css";

function Reviews() {
  return (
    <section className="reviews">
      <h2>Пікірлер</h2>

      {/* Play Market логотипі */}
      <div className="play-logo">
        <img src="/playmarket.png" alt="Play Market" />
      </div>

      {/* Карточкалар */}
      <div className="reviews-grid">
        <div className="review-card">
          <img src="/images/user1.png" alt="User 1" />
          <h3>Айдар, 23 жас</h3>
          <p className="job">Студент</p>
          <p className="text">Ооо брат, приложение 🔥! Реклама аз, выбор көп, сервис тез. Реально ұнайды, прям кайф!</p>
        </div>

        <div className="review-card">
          <img src="/images/user2.png" alt="User 2" />
          <h3>Ермек, 35 жас</h3>
          <p className="job">Механик</p>
          <p className="text">Мен көптен бері осындай конкурентов көрмеппін. Приложение жақсы, бірақ кішкене минустар бар. Разрабтар түзеп қояды деп ойлаймын.</p>
        </div>

        <div className="review-card">
          <img src="/images/user3.png" alt="User 3" />
          <h3>Айнұр, 27 жас</h3>
          <p className="job">Маркетолог</p>
          <p className="text">Маған қатты ұнады 🤩! ІІ ассистент прям подружка сияқты. Машинадан түк түсінбеймін, бірақ ол бәрін түсіндіріп, көмектесіп отыр.</p>
        </div>

        <div className="review-card">
          <img src="/images/user4.png" alt="User 4" />
          <h3>Руслан, 40 жас</h3>
          <p className="job">Бизнесмен</p>
          <p className="text">Приложение реально уақытты үнемдейді ⏱️. Бұрын машина іздеу головная боль еді, қазір бір-екі кликте табамын.</p>
        </div>

        <div className="review-card">
          <img src="/images/user5.png" alt="User 5" />
          <h3>Жанар, 30 жас</h3>
          <p className="job">Мұғалім</p>
          <p className="text">Интерфейс ұнады, қарапайым әрі түсінікті. Балаларға да көрсеттім, бәрі «вау» деді 😊.</p>
        </div>

        <div className="review-card">
          <img src="/images/user6.png" alt="User 6" />
          <h3>Марат, 28 жас</h3>
          <p className="job">Программист</p>
          <p className="text">ИИ ассистент супер! Кейде приколдап жауап береді 😂, бірақ жалпы өте пайдалы. Машина таңдауда көмектесті.</p>
        </div>
      </div>

      {/* Рейтинг жұлдыздар */}
      <div className="rating">
        <span className="star gold">★</span>
        <span className="star gold">★</span>
        <span className="star gold">★</span>
        <span className="star gold">★</span>
        <span className="star half">★</span>
        <span className="score">4.7/5</span>
      </div>
    </section>
  );
}

export default Reviews;
