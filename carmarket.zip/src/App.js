import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./Header";
import Catalog from "./Catalog";
import About from "./About";
import Reviews from "./Reviews";
import Contacts from "./Contacts";

function App() {
  return (
    <Router>
      <Header />
      <Routes>
        {/* Root ашылғанда бірден Каталог көрсетіледі */}
        <Route path="/" element={<Catalog />} />

        <Route path="/catalog" element={<Catalog />} />
        <Route path="/about" element={<About />} />
        <Route path="/reviews" element={<Reviews />} />
        <Route path="/contacts" element={<Contacts />} />
      </Routes>
    </Router>
  );
}

export default App;
