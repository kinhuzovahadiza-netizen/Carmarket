import "./Catalog.css";

function Catalog() {
  const cars = [
    {
      photo: "/cars/camry.jpg",
      brand: "Toyota",
      model: "Camry",
      price: "12 500 000 ₸",
      color: "Ақ",
      year: "2020",
      mileage: "45 000 км",
      credit: true,
      description: "Toyota Camry — сенімділік пен жайлылықтың символы. Бұл көлік қала ішінде де, ұзақ сапарларда да мінсіз серік болады. Кең салон мен жұмсақ аспа әрбір сапарды ыңғайлы етеді. Қауіпсіздік жүйелері жүргізуші мен жолаушыларға сенімділік береді. Үнемді қозғалтқыш жанармай шығынын азайтады. Camry — отбасы мен бизнес үшін тамаша таңдау.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/bmw.jpg",
      brand: "BMW",
      model: "X5",
      price: "28 000 000 ₸",
      color: "Қара",
      year: "2021",
      mileage: "30 000 км",
      credit: false,
      description: "BMW X5 — қуат пен сәнділікті үйлестірген премиум жол талғамайтын көлік. Оның дизайны иесінің мәртебесін айқын көрсетеді. Толық жетекті жүйе кез келген жолда сенімді қозғалысты қамтамасыз етеді. Салон жоғары сапалы материалдармен жабдықталған. Заманауи технологиялар жайлылық пен қауіпсіздікті арттырады. Бұл көлік — бедел мен динамиканы бағалайтындарға арналған.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/mercedes.jpg",
      brand: "Mercedes-Benz",
      model: "E200",
      price: "18 500 000 ₸",
      color: "Сұр",
      year: "2019",
      mileage: "60 000 км",
      credit: true,
      description: "Mercedes-Benz E200 — стиль мен жайлылықты бағалайтындарға арналған бизнес-седан. Кузовтың әсем сызықтары мен фирмалық радиатор торы мәртебені айқындайды. Ішкі салон кең әрі премиум материалдармен әрленген. Қозғалтқыш қуатты әрі үнемді. Қауіпсіздік жүйелері әр сапарды сенімді етеді. Бұл көлік — іскер адамдардың сенімді серігі.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/kia.jpg",
      brand: "Kia",
      model: "Sportage",
      price: "10 800 000 ₸",
      color: "Қызыл",
      year: "2022",
      mileage: "15 000 км",
      credit: true,
      description: "Kia Sportage — белсенді өмірге арналған заманауи кроссовер. Жарқын дизайны жолда ерекше көрінеді. Кең салон мен ыңғайлы орындықтар әр сапарды жайлы етеді. Қауіпсіздік технологиялары жүргізуші мен жолаушыларға сенімділік береді. Үнемді қозғалтқыш жанармай шығынын азайтады. Бұл көлік отбасы мен саяхат үшін тамаша таңдау.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/hyundai.jpg",
      brand: "Hyundai",
      model: "Sonata",
      price: "9 800 000 ₸",
      color: "Көк",
      year: "2021",
      mileage: "25 000 км",
      credit: true,
      description: "Hyundai Sonata — заманауи дизайн мен практикалықты үйлестірген стильді седан. Кең салон жүргізуші мен жолаушыларға жайлылық береді. Қауіпсіздік технологиялары әр сапарды сенімді етеді. Үнемді қозғалтқыш шығынды азайтады. Жұмсақ аспа қала жолдарына бейімделген. Sonata — отбасы мен іскерлік кездесулерге мінсіз таңдау.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/lexus.jpg",
      brand: "Lexus",
      model: "RX 350",
      price: "22 000 000 ₸",
      color: "Ақ",
      year: "2020",
      mileage: "40 000 км",
      credit: false,
      description: "Lexus RX 350 — сән-салтанат пен сенімділікті үйлестірген премиум кроссовер. Оның дизайны иесінің мәртебесін көрсетеді. Салон жоғары сапалы материалдармен жабдықталған. Жолдағы жайлылықты аспа қамтамасыз етеді. Қозғалтқыш қуатты әрі үнемді. RX 350 — жайлылық пен беделді бағалайтындарға арналған.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/audi.jpg",
      brand: "Audi",
      model: "A6",
      price: "19 500 000 ₸",
      color: "Қара",
      year: "2019",
      mileage: "55 000 км",
      credit: true,
      description: "Audi A6 — динамика мен әсемдікті үйлестірген бизнес-седан. Қатаң дизайны иесінің сенімділігін көрсетеді. Салон кең әрі заманауи технологиялармен жабдықталған. Қозғалтқыш қуатты әрі үнемді. Аспа жайлы қозғалысты қамтамасыз етеді. Audi A6 — сапаны бағалайтын іскер адамдарға арналған.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/nissan.jpg",
      brand: "Nissan",
      model: "Qashqai",
      price: "8 200 000 ₸",
      color: "Сұр",
      year: "2022",
      mileage: "20 000 км",
      credit: true,
      description: "Nissan Qashqai — белсенді өмірге арналған ықшам кроссовер. Заманауи дизайны жолда ерекше көрінеді. Салон ыңғайлы әрі кең. Қауіпсіздік жүйелері сенімділік береді. Үнемді қозғалтқыш шығынды азайтады. Qashqai — қала мен саяхат үшін мінсіз таңдау.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/honda.jpg",
      brand: "Honda",
      model: "Accord",
      price: "11 200 000 ₸",
      color: "Ақ",
      year: "2021",
      mileage: "35 000 км",
      credit: false,
      description: "Honda Accord — практикалық пен стильді үйлестірген сенімді седан. Заманауи әрі әсем дизайны көз тартады. Салон кең әрі ыңғайлы. Қауіпсіздік технологиялары әр сапарды сенімді етеді. Қозғалтқыш қуатты әрі үнемді. Accord — сапа мен ұзақ мерзімділікті бағалайтындарға арналған.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/vw.jpg",
      brand: "Volkswagen",
      model: "Tiguan",
      price: "13 500 000 ₸",
      color: "Күміс",
      year: "2020",
      mileage: "50 000 км",
      credit: true,
      description: "Volkswagen Tiguan — практикалық пен жайлылықты үйлестірген заманауи кроссовер. Қатаң әрі стильді дизайны көзге түседі. Салон кең әрі заманауи технологиялармен жабдықталған. Аспа қозғалысты жайлы етеді. Қозғалтқыш сенімді әрі үнемді. Tiguan — отбасы мен белсенді адамдарға арналған.",
      phone: "+77•••••••••"
    },
    {
      photo: "/cars/mazda.jpg",
      brand: "Mazda",
      model: "CX-5",
      price: "12 000 000 ₸",
      color: "Қызыл",
      year: "2021",
      mileage: "28 000 км",
      credit: true,
      description: "Mazda CX-5 — динамика мен стильді үйлестірген кроссовер. Жарқын дизайны жолда ерекше көрінеді. Салон ыңғайлы әрі заманауи. Қауіпсіздік жүйелері сенімділік береді. Қозғалтқыш қуатты әрі үнемді. CX-5 — драйв пен жайлылықты бағалайтындарға арналған.",
      phone: "+77•••••••••"
    },
{
  photo: "/cars/chevrolet.jpg",
  brand: "Chevrolet",
  model: "Malibu",
  price: "9 500 000 ₸",
  color: "Көк",
  year: "2019",
  mileage: "60 000 км",
  credit: false,
  description: "Chevrolet Malibu — стиль мен практикалықты үйлестірген заманауи седан. Оның дизайны әсем әрі заманауи көрінеді. Салон кең, жүргізуші мен жолаушыларға ыңғайлы жағдай жасайды. Қауіпсіздік жүйелері әр сапарды сенімді етеді. Қозғалтқыш үнемді әрі сенімді жұмыс істейді. Malibu — қаладағы күнделікті қозғалыс пен саяхат үшін тамаша таңдау.",
  phone: "+77•••••••••"
}
   ];

    const scrollToBottom = () => {
    window.scrollTo({ top: document.body.scrollHeight, behavior: "smooth" });
  };

  return (
    <>
      {/* 🚗 Каталог бөлімі */}
      <div className="catalog">
        {cars.map((car, index) => (
          <div className="car-card" key={index} style={{ position: "relative" }}>
            {index < 2 && <div className="hot-offer">ҚЫЗУ ҰСЫНЫС</div>}
            <img src={car.photo} alt={car.brand + " " + car.model} />
            <h3>{car.brand} {car.model}</h3>

            {index === 0 ? (
              <>
                <p className="price-old">12 500 000 ₸</p>
                <p className="price-discount">Жеңілдікпен баға: 11 250 000 ₸</p>
              </>
            ) : index === 1 ? (
              <>
                <p className="price-old">28 000 000 ₸</p>
                <p className="price-discount">Жеңілдікпен баға: 25 200 000 ₸</p>
              </>
            ) : (
              <p className="price">{car.price}</p>
            )}

            <p>{car.color} • {car.year} • {car.mileage}</p>
            <p>{car.credit ? "Несиеге болады" : "Несиесіз"}</p>
            <p className="desc">{car.description}</p>
            <p className="phone">{car.phone}</p>
            <button className="buy-btn" onClick={scrollToBottom}>Сатып алу</button>
          </div>
        ))}
      </div>

      {/* 📲 Қолданбаны жүктеу бөлімі */}
      <div className="app-promo">
        <div className="promo-content">
          <ul className="promo-left">
            <li>🔹 Қазіргі уақытта <b>12 000+</b> хабарландыру</li>
            <li>👥 <b>5 000+</b> белсенді қолданушы</li>
            <li>⭐ Play Market бағасы: <b>4.7/5</b></li>
          </ul>

          <div className="promo-center">
            <a
              href="https://drive.google.com/uc?export=download&id=1UCuVwKzmlvB5lmJGe-LSx_Ktjg0NAeS8"
              target="_blank"
              rel="noopener noreferrer"
              className="download-btn"
            >
              <img src="/playmarket.png" alt="Play Market" className="play-icon" />
              Қолданбаны жүктеу
            </a>
          </div>

          <ul className="promo-right">
            <li>🤖 ІІ ассистент — дауыспен іздеу және кеңес</li>
            <li>⚡ Жылдам фильтрлер және ыңғайлы интерфейс</li>
            <li>📌 Жарнамаларды сақтап, сүйіктіге қосу мүмкіндігі</li>
            <li>📞 Қолданба ішінен бірден қоңырау шалу</li>
            <li>💳 Несиеге алу мүмкіндігі көрсетіледі</li>
          </ul>
        </div>
      </div>
    </>
  );
}

export default Catalog;





