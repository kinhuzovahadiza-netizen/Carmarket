function Blog() {
  return <h2>Блог (пустая страница)</h2>;
}
export default Blog;
