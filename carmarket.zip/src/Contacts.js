import React from "react";
import "./Contacts.css";

function Contacts() {
  return (
    <section className="contacts">
      <h2>Байланыс</h2>

      <div className="contact-info">
        <p><strong>📍 Мекенжай:</strong> Алматы облысы, Іле ауданы, Өтеген батыр ауылы, Қапал батыр көшесі 4</p>
        <p><strong>📞 Телефон:</strong> <a href="tel:+77073171044">+7 (707) 317-1044</a>, <a href="tel:+77000906525">+7 (700) 090-6525</a></p>
        <p><strong>✉️ Email:</strong> <a href="mailto:tezauto.almaty@gmail.com">tezauto.almaty@gmail.com</a></p>
      </div>

      <div className="socials">
        <h3>Әлеуметтік желілер:</h3>
        <a href="https://instagram.com/tezauto_official">Instagram</a>
        <a href="https://tiktok.com/@tezauto">TikTok</a>
        <a href="https://youtube.com/@tezauto">YouTube</a>
        <a href="https://facebook.com/tezauto">Facebook</a>
      </div>

      <div className="map">
        <h3>Карта:</h3>
        <iframe
          src="https://www.google.com/maps?q=Алматы+облысы+Іле+ауданы+Өтеген+батыр+ауылы+Қапал+батыр+4&output=embed"
          width="100%"
          height="350"
          style={{ border: 0 }}
          allowFullScreen=""
          loading="lazy"
        ></iframe>
      </div>
    </section>
  );
}

export default Contacts;
