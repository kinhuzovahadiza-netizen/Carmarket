import { Link } from "react-router-dom";
import React, { useState, useEffect } from "react";
import "./Header.css";

function Header() {
  const [hideHeader, setHideHeader] = useState(false);
  const [lastScroll, setLastScroll] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScroll = window.scrollY;
      if (currentScroll > lastScroll && currentScroll > 80) {
        // төменге скролл → жасыру
        setHideHeader(true);
      } else {
        // жоғарыға скролл → көрсету
        setHideHeader(false);
      }
      setLastScroll(currentScroll);
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, [lastScroll]);

  return (
    <header className={`header ${hideHeader ? "hidden" : ""}`}>
      {/* Логотип */}
      <div className="logo">
        <img src="/logo.png" alt="TEZauto" />
      </div>

      {/* Меню */}
      <nav className="menu">
        <Link to="/catalog">Каталог</Link>
        <Link to="/about">Біз туралы</Link>
        <Link to="/reviews">Пікірлер</Link>
        <Link to="/contacts">Байланыс</Link>
      </nav>

      {/* Әлеуметтік желілер — Байланыс пен Көлікті сату ортасында */}
      <div className="socials">
        <a href="https://instagram.com/tezauto_official">
          <img src="/icons/instagram.svg" alt="Instagram" />
        </a>
        <a href="https://tiktok.com">
          <img src="/icons/tiktok.svg" alt="TikTok" />
        </a>
        <a href="https://youtube.com">
          <img src="/icons/youtube.svg" alt="YouTube" />
        </a>
      </div>

      {/* Батырма */}
      <button className="sell-btn">Көлікті сату</button>
    </header>
  );
}

export default Header;
